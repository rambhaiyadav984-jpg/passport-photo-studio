import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  // IMPORTANT: Before publishing, change this to a unique permanent ID.
  // Example format: in.yourbrand.passportphotostudio
  appId: 'in.example.passportphotostudio',
  appName: 'Passport Photo Studio',
  webDir: 'www',
  bundledWebRuntime: false
};

export default config;
